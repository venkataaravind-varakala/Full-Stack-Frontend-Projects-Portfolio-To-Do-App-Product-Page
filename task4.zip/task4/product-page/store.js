const products = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", price: 2499, rating: 4.5 },
  { id: 2, name: "Gaming Mouse", category: "Electronics", price: 1499, rating: 4.2 },
  { id: 3, name: "Yoga Mat", category: "Fitness", price: 899, rating: 4.0 },
  { id: 4, name: "Running Shoes", category: "Footwear", price: 3299, rating: 4.6 },
  { id: 5, name: "Coffee Maker", category: "Home", price: 1999, rating: 4.1 },
  { id: 6, name: "Desk Lamp", category: "Home", price: 799, rating: 3.9 },
  { id: 7, name: "Smartwatch", category: "Electronics", price: 5599, rating: 4.4 },
  { id: 8, name: "Dumbbell Set", category: "Fitness", price: 2599, rating: 4.3 },
  { id: 9, name: "Sandals", category: "Footwear", price: 1199, rating: 3.8 },
  { id: 10, name: "Backpack", category: "Accessories", price: 1399, rating: 4.0 },
  { id: 11, name: "Sunglasses", category: "Accessories", price: 999, rating: 3.7 },
  { id: 12, name: "T‑Shirt", category: "Clothing", price: 699, rating: 4.1 },
  { id: 13, name: "Jeans", category: "Clothing", price: 1699, rating: 4.2 },
  { id: 14, name: "Blender", category: "Home", price: 2299, rating: 4.5 },
  { id: 15, name: "Keyboard", category: "Electronics", price: 1999, rating: 4.0 },
  { id: 16, name: "Water Bottle", category: "Fitness", price: 499, rating: 4.6 },
];

// DOM refs
const grid = document.getElementById('grid');
const search = document.getElementById('search');
const category = document.getElementById('category');
const priceMin = document.getElementById('priceMin');
const priceMax = document.getElementById('priceMax');
const sort = document.getElementById('sort');
const apply = document.getElementById('apply');
const reset = document.getElementById('reset');

// Populate categories
const categories = ["All", ...Array.from(new Set(products.map(p => p.category)))];
category.innerHTML = categories.map(c => `<option value="${c}">${c}</option>`).join("");

function render(list) {
  grid.innerHTML = "";
  list.forEach(p => {
    const el = document.createElement('article');
    el.className = "card";
    el.innerHTML = `
      <div style="height:140px;background:#f3f4f6;border-radius:10px;"></div>
      <h3>${p.name}</h3>
      <div class="rating">★ ${p.rating.toFixed(1)} · ${p.category}</div>
      <div class="price">₹${p.price.toLocaleString('en-IN')}</div>
    `;
    grid.appendChild(el);
  });
}

function applyFilters() {
  const q = (search.value || "").toLowerCase();
  let list = products.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.category.toLowerCase().includes(q)
  );
  if (category.value && category.value !== "All") {
    list = list.filter(p => p.category === category.value);
  }
  const min = Number(priceMin.value || 0);
  const max = Number(priceMax.value || Number.POSITIVE_INFINITY);
  list = list.filter(p => p.price >= min && p.price <= max);

  const [key, dir] = sort.value.split('-'); // rating-desc, price-asc
  list.sort((a, b) => {
    if (key === 'name') return a.name.localeCompare(b.name) * (dir === 'asc' ? 1 : -1);
    if (key === 'price') return (a.price - b.price) * (dir === 'asc' ? 1 : -1);
    if (key === 'rating') return (a.rating - b.rating) * (dir === 'asc' ? 1 : -1);
    return 0;
  });

  render(list);
}

apply.addEventListener('click', applyFilters);
reset.addEventListener('click', () => {
  search.value = ""; category.value = "All"; priceMin.value = ""; priceMax.value = ""; sort.value = "rating-desc"; applyFilters();
});
[search, category, priceMin, priceMax, sort].forEach(el => el.addEventListener('change', applyFilters));

applyFilters();
