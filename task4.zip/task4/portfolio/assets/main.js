
// Typewriter loop
const phrases = ["AI & ML Student", "Frontend Developer", "IoT + Embedded Enthusiast", "Open Source Contributor"];
let idx = 0, pos = 0, forward = true;
const el = document.querySelector('.typewriter');
function tick(){
  const p = phrases[idx];
  if (forward){ pos++; el.textContent = p.slice(0,pos); if(pos===p.length){ forward=false; setTimeout(tick,900); return;} }
  else { pos--; el.textContent = p.slice(0,pos); if(pos===0){ forward=true; idx=(idx+1)%phrases.length; } }
  setTimeout(tick, forward?80:40);
}
if(el) tick();

// floating tech particles - simple circles
const svgNS = "http://www.w3.org/2000/svg";
function makeCircle(cx, cy, r, delay){
  const c = document.createElementNS(svgNS, 'circle');
  c.setAttribute('cx', cx); c.setAttribute('cy', cy); c.setAttribute('r', r);
  c.setAttribute('fill', 'none'); c.setAttribute('stroke', 'url(#g)'); c.setAttribute('stroke-width', 0.8);
  c.style.opacity = 0.6; c.style.transformOrigin='center';
  c.animate([{transform:'translateY(0)'},{transform:'translateY(-8px)'},{transform:'translateY(0)'}],{duration:3000+delay,iterations:Infinity,delay:delay});
  return c;
}
const svg = document.getElementById('bgsvg');
if(svg){
  for(let i=0;i<10;i++){
    const c = makeCircle(40+i*110, 30 + (i%3)*50, 28 - (i%5)*3, i*120);
    svg.appendChild(c);
  }
}

// active nav link
(function mark(){ const path = location.pathname.split('/').pop()||'index.html'; document.querySelectorAll('.menu a').forEach(a=>{ if(a.getAttribute('href').endsWith(path)) a.classList.add('active') }) })();

// contact form -> localStorage (demo)
const cf = document.getElementById('contactForm');
if(cf){
  cf.addEventListener('submit', e=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(cf).entries());
    const msgs = JSON.parse(localStorage.getItem('contact_messages')||'[]');
    msgs.push({...data, date:new Date().toISOString()});
    localStorage.setItem('contact_messages', JSON.stringify(msgs));
    alert('Thanks! Message saved locally (demo).');
    cf.reset();
  });
}
