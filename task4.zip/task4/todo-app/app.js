const STORAGE_KEY = "todo_items_v1";

function uid() { return Math.random().toString(36).slice(2, 9); }

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch { return []; }
}
function save(items) { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }

let items = load();

// DOM Refs
const list = document.getElementById('list');
const newTask = document.getElementById('newTask');
const addBtn = document.getElementById('add');
const due = document.getElementById('due');
const priority = document.getElementById('priority');
const statusFilter = document.getElementById('statusFilter');
const sortBy = document.getElementById('sortBy');
const clearDone = document.getElementById('clearDone');
const exportBtn = document.getElementById('export');
const search = document.getElementById('search');

function render() {
  const q = (search.value || "").toLowerCase();
  let view = items.filter(i => i.title.toLowerCase().includes(q));

  // Filter by status
  if (statusFilter.value === 'open') view = view.filter(i => !i.done);
  if (statusFilter.value === 'done') view = view.filter(i => i.done);

  // Sort
  view.sort((a, b) => {
    if (sortBy.value === 'created') return new Date(b.created) - new Date(a.created);
    if (sortBy.value === 'due') return (a.due || "9999-12-31").localeCompare(b.due || "9999-12-31");
    if (sortBy.value === 'priority') {
      const order = { high: 0, normal: 1, low: 2 };
      return order[a.priority] - order[b.priority];
    }
    return 0;
  });

  list.innerHTML = "";
  for (const i of view) {
    const el = document.createElement('div');
    el.className = 'item' + (i.done ? ' done' : '');
    el.innerHTML = `
      <input type="checkbox" ${i.done ? 'checked' : ''} aria-label="Toggle complete">
      <div>
        <div>${i.title}</div>
        <div class="meta">
          ${i.due ? `<span class="tag">Due: ${i.due}</span>` : ''}
          <span class="tag">Priority: ${i.priority}</span>
          <span class="tag">Created: ${new Date(i.created).toLocaleString()}</span>
        </div>
      </div>
      <div class="controls">
        <button title="Edit">Edit</button>
        <button title="Delete">Delete</button>
      </div>
    `;
    const [checkbox,, controls] = el.children;
    const [editBtn, delBtn] = controls.children;

    checkbox.addEventListener('change', () => {
      i.done = checkbox.checked; save(items); render();
    });
    delBtn.addEventListener('click', () => {
      items = items.filter(x => x.id !== i.id); save(items); render();
    });
    editBtn.addEventListener('click', () => {
      const title = prompt("Edit task", i.title);
      if (title && title.trim()) { i.title = title.trim(); save(items); render(); }
    });

    list.appendChild(el);
  }
}

function addTask() {
  const title = (newTask.value || "").trim();
  if (!title) return;
  items.unshift({ id: uid(), title, created: new Date().toISOString(), done: false, due: due.value || null, priority: priority.value });
  save(items);
  newTask.value = ""; due.value = ""; priority.value = "normal";
  render();
}

addBtn.addEventListener('click', addTask);
newTask.addEventListener('keydown', (e) => { if (e.key === 'Enter') addTask(); });
[statusFilter, sortBy].forEach(el => el.addEventListener('change', render));
clearDone.addEventListener('click', () => {
  items = items.filter(i => !i.done); save(items); render();
});
exportBtn.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(items, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = "todo_export.json"; a.click();
  URL.revokeObjectURL(url);
});
search.addEventListener('input', render);

render();
